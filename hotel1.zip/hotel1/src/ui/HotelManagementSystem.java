package ui;

import operations.HotelManagementOperations;

public class HotelManagementSystem {
	 public static void main(String[] args) {
	        HotelManagementOperations operations = new HotelManagementOperations();
	        operations.start();
	    }
}
