package services;

import java.util.ArrayList;
import java.util.List;

import entity.Booking;
import entity.Guest;
import entity.Room;
import exception.RoomNotAvailableException;
import exception.RoomNotFoundException;

public class HotelManagementService {
	 private List<Room> rooms;
	    private List<Booking> bookings;

	    public HotelManagementService() {
	        rooms = new ArrayList<>();
	        bookings = new ArrayList<>();
	        initializeRooms();
	    }

	  
	    private void initializeRooms() {
	        rooms.add(new Room(101, "Single", 100));
	        rooms.add(new Room(102, "Double", 150));
	        rooms.add(new Room(103, "Suite", 300));
	    }

	    public List<Room> getAvailableRooms() {
	        List<Room> availableRooms = new ArrayList<>();
	        for (Room room : rooms) {
	            if (!room.isBooked()) {
	                availableRooms.add(room);
	            }
	        }
	        return availableRooms;
	    }

	    public void bookRoom(int roomNumber, Guest guest, int days) throws RoomNotFoundException, RoomNotAvailableException {
	        Room room = findRoomByNumber(roomNumber);

	        if (room == null) {
	            throw new RoomNotFoundException("Room not found.");
	        }

	        if (room.isBooked()) {
	            throw new RoomNotAvailableException("Room is already booked.");
	        }

	        room.setBooked(true);
	        Booking booking = new Booking(guest, room, days);
	        bookings.add(booking);

	        System.out.println("Booking successful for " + guest.getName() + " in Room " + room.getRoomNumber());
	    }

	    public Room findRoomByNumber(int roomNumber) {
	        for (Room room : rooms) {
	            if (room.getRoomNumber() == roomNumber) {
	                return room;
	            }
	        }
	        return null;
	    }

	    public List<Booking> getAllBookings() {
	        return bookings;
	    }
}
