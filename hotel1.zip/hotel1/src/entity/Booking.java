package entity;


public class Booking {
	 private Guest guest;
	    private Room room;
	    private int numberOfDays;
	    private double totalCost;

	    public Booking(Guest guest, Room room, int numberOfDays) {
	        this.guest = guest;
	        this.room = room;
	        this.numberOfDays = numberOfDays;
	        this.totalCost = numberOfDays * room.getPrice();
	    }

	    public Guest getGuest() {
	        return guest;
	    }

	    public Room getRoom() {
	        return room;
	    }

	    public int getNumberOfDays() {
	        return numberOfDays;
	    }

	    public double getTotalCost() {
	        return totalCost;
	    }

	    @Override
	    public String toString() {
	        return "Booking [Guest: " + guest + ", Room: " + room + ", Days: " + numberOfDays + ", Total Cost: $" + totalCost + "]";
	    }
}
