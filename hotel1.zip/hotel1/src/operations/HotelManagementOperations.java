package operations;

import java.util.Scanner;

import entity.Guest;
import exception.RoomNotAvailableException;
import exception.RoomNotFoundException;
import services.HotelManagementService;

public class HotelManagementOperations {
	private HotelManagementService managementService;
    private Scanner scanner;

    public HotelManagementOperations() {
        managementService = new HotelManagementService();
        scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            showMenu();
            int option = scanner.nextInt();
            switch (option) {
                case 1:
                    viewRooms();
                    break;
                case 2:
                	
                    try {
                        bookRoom();
                    } catch (RoomNotFoundException | RoomNotAvailableException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                    
                case 3:
                    viewBookings();
                    break;
                    
                case 4:
                    System.out.println("Exiting...");
                    return;
                    
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    private void showMenu() {
        System.out.println("\nHotel Management System:");
        System.out.println("1. View Available Rooms");
        System.out.println("2. Book a Room");
        System.out.println("3. View All Bookings");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");
    }

    private void viewRooms() {
        System.out.println("Available Rooms:");
        managementService.getAvailableRooms().forEach(System.out::println);
    }

    private void bookRoom() throws RoomNotFoundException, RoomNotAvailableException {
        scanner.nextLine(); 
        System.out.print("Enter Guest Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Guest Contact Number: ");
        String contact = scanner.nextLine();
        Guest guest = new Guest(name, contact);

        viewRooms();
        System.out.print("Enter Room Number to Book: ");
        int roomNumber = scanner.nextInt();
        System.out.print("Enter Number of Days: ");
        int days = scanner.nextInt();

        managementService.bookRoom(roomNumber, guest, days);
    }

    private void viewBookings() {
        System.out.println("All Bookings:");
        managementService.getAllBookings().forEach(System.out::println);
    }
}
